

# Example Keyed

- Id: 10
- Hash: 9b87da04349185080af34e04895d4d66
- Properties:
    - Length:
        - Type: number
        - Enabled: false
        - Value: -1
    - Description
        - Type: string
        - Enabled: true
        - Value: example

___________________________________________________


# Example Array

- Id: 10
- Hash: 9b87da04349185080af34e04895d4d66
- Properties:
    - Property:
        - Name: length
        - Type: number
        - Enabled: false
        - Value: -1
    - Property:
        - Name: description
        - Type: string
        - Enabled: true
        - Value: example

___________________________________________________


# Example Array

- Id: 10
- Hash: 9b87da04349185080af34e04895d4d66
- Property:
    - Name: length
    - Type: number
    - Enabled: false
    - Value: -1
- Property:
    - Name: description
    - Type: string
    - Enabled: true
    - Value: example
