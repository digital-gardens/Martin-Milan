# Markdown Object Language (MOL) Specification

STATUS: DRAFT / IN PROGRESS
VERSION: 0.1.1

## Overview

Markdown Object Language (MOL) is a nested object notation built on top of markdown-like text.
It is intended for human-editable structured data such as records, schemas, configuration files, and other markdown-adjacent object documents.

MOL is deliberately flexible. Multiple markdown-shaped forms can describe the same object tree.
This flexibility is intended to make MOL practical for both humans and LLMs.




## Intended Use and Limits

MOL is a good fit when authors want to stay close to normal markdown while storing structured data.

Common uses include:

- Records
- Schemas
- Configuration files
- LLM-facing structured documents

MOL is intentionally text-first and loose. This has tradeoffs:

- It is less suitable for deeply nested structures.
- Primitive types are not fully defined by the markup itself.
- Higher-level deserializers are expected to apply schema, typing, and native object/array mapping rules.




## Data Model

A MOL document represents a recursively nested object.

Each object contains an ordered list of entries:

- Each entry has a key.
- A key may map to either a scalar value or another object.
- Keys are not required to be unique.
- Repeated sibling keys represent repeated entries and may be deserialized as arrays.

Examples:

- `Property:` repeated multiple times means `Property` is an array-like key.
- `Properties:` followed by distinct child keys means `Properties` is an object-like key.

Parsers should preserve source order. Higher-level deserializers may choose how to map repeated keys to arrays or records.




## Structural Forms

The following forms are structurally equivalent when they describe the same tree:

- Headings
- Plain `Key: Value` entries
- Plain `Key:` or `Key` object entries
- Markdown list items using `-`, `*`, `+`, or `1.`

### Root Heading Level

Headings are structural. 

The first structural heading level used in a document becomes heading level 1 for that document's structure.

Examples:

- If the first structural heading is `#`, then `#` is level 1, `##` is level 2, and so on.
- If the first structural heading is `##`, then `##` is level 1, `###` is level 2, and so on.

Multiple root headings at that same normalized level are valid:

```md
# Level 1 A
Id: 10

# Level 1 B
Id: 11
```

These are sibling entries at the document root, and define the resulting root object to be an array.

By convention, authors may use the first heading as a human-facing document title or description.

### Key-Value Entry

A single-line property is written as:

```md
Key: Value
```

This creates a scalar entry named `Key` with the text value `Value`.

### Key-Only Entry

An entry with deferred content may be written as either:

```md
Key:
```

or

```md
Key
```

This creates an entry named `Key`.

Its content is determined by what follows:

- If nested structural entries follow, `Key` is an object entry.
- If a text body follows, `Key` is a scalar text entry.

### Heading Entry

Headings create named object scopes:

```md
## Properties
### Length
Type: number
```

This is equivalent to:

```md
Properties:
    Length:
        Type: number
```

Headings may also take a text body instead of child entries.

Heading depth is determined solely by the number of ``#`` markers, normalized to the document's shallowest
  structural heading level. Indentation does not affect heading depth.

### List Entry

List markers are syntactic sugar and do not change the data model:

```md
- Id: 10
* Hash: abc
1. Enabled: true
```

All of the following list markers are valid:

- `-`
- `*`
- `+`
- `1.`, `2.`, etc.

List syntax alone does not imply array semantics.
Array-like behavior comes from repeated sibling entries or from higher-level deserializer conventions.

## Nesting Rules

### Indentation-Based Nesting

For plain entries and list entries, nesting is determined by indentation:

- Greater indentation means child content.
- Returning to a previous indentation closes the nested scope.
- Parsers should accept tabs or consistent spaces.
- Writers should prefer tab characters for emitted indentation.

Indented content may be pasted from elsewhere without being reformatted, as long as its relative indentation remains intact.

### Heading-Based Nesting

For headings, nesting is determined by normalized heading level:

- The shallowest structural heading level in the document is level 1.
- The next deeper heading level is its child level.
- Headings at the same normalized depth are siblings.

Examples:

- If the root heading level is `#`, then `##` is a child of `#`.
- If the root heading level is `##`, then `###` is a child of `##`.

Indentation does not change heading depth. This allows heading blocks to be indented for readability or pasted into larger structures without changing their semantic level.

### Mixed Forms

Heading-based and indentation-based forms may be mixed in the same document.

For example, a heading may contain plain entries, list entries, or additional headings.




## Scalar Values

MOL itself is text-first and does not impose a strict primitive type system.

At the core syntax layer, scalar values are preserved as strings.

Values such as `10`, `false`, `number`, and `example` are written as text. Higher-level deserializers may coerce unquoted scalar strings to numbers, booleans, enums, or other domain-specific types.

Scalar values may be expressed either inline or as a text body.

Inline scalar example:

```md
Id: 10
```

Text-body scalar example:

```md
## Id

10
```

### Inline Quoted Values

An inline scalar whose entire value is wrapped in matching single quotes or matching double quotes is an explicit string literal.

Supported forms:

```md
Year: "2025"
Flag: 'false'
```

Quoted inline scalar values:

- Must occupy the full inline value after `Key:`
- Are preserved as strings by the parser
- Must not be auto-coerced by the parser to numbers, booleans, or other native types

Only full-value quoting has special meaning. Partial quoting inside an otherwise unquoted inline value is not defined as a distinct scalar form by the core syntax.

Basic escapes are supported inside quoted inline values:

- `\\`
- `\"`
- `\'`
- `\n`
- `\r`
- `\t`

Example:

```md
Message: "line 1\nline 2"
Path: 'C:\\temp\\cache'
Quote: "\"hello\""
```

### Date and Datetime Conventions

ISO 8601 date and datetime values are an officially supported scalar convention.

Examples:

```md
Date: 2026-04-02
Timestamp: 2026-04-02T18:30:45Z
Timestamp With Offset: 2026-04-02T20:30:45+02:00
```

ISO 8601 date and datetime values are preserved as strings by the parser and must not be auto-coerced to native date objects at the syntax layer.

Higher-level deserializers may interpret these string values according to schema or application rules.

### Text-Body Values

A text body is a scalar value formed by plain text lines that appear beneath a heading entry or a key-only entry.

Examples:

```md
Description:
    This is a single-line value.
```

```md
## Description

This is line one.
This is line two.
```

```md
## Notes

First paragraph.

Second paragraph.
```

Text-body rules:

- A text body begins when the first non-blank, non-comment child line of a heading entry or key-only entry is plain text rather than another structural entry.
- A text body may contain multiple lines.
- Blank lines inside the text body are preserved as part of the value.
- A text body ends when the parser encounters the next sibling or ancestor structural entry, or the end of the document.
- A heading entry or key-only entry cannot contain both a text body and child structural entries at the same scope.

For indentation-based entries, the text body is formed from the indented child lines belonging to that entry.

For heading entries, the text body is formed from the subsequent plain text lines until another heading at the same or shallower normalized level, another enclosing structural boundary, or end of document.

### Escaping Text Bodies

If a text-body line would otherwise be parsed as MOL structure, authors should escape it using normal markdown escaping or wrap the value in a fenced code block.

Examples:

```md
## Example

\# not a heading
\- not a list item
Key\: not a key-value entry
```

````md
## Script

```txt
# literal heading text
Name: literal text
- literal list text
```
````

When a fenced code block is used as a text body, its contents are taken literally as the scalar value body until the closing fence.




## Arrays and Duplicate Keys

Sibling keys are allowed to repeat.

Repeated keys represent repeated entries:

```md
Property:
    Name: length
Property:
    Name: description
```

This is the canonical array-like pattern in MOL.

Distinct sibling keys represent a keyed object:

```md
Properties:
    Length:
    Description:
```

Whether repeated keys are exposed as arrays, multisets, or ordered duplicate fields is an implementation choice above the syntax layer, but source order should be preserved.

The distinction between the two forms is the key, not the content. Naming what would have been
repeated entries after something in the entries themselves turns array-like data into object-like
data, which is a deliberate trade of shape for readability (see Array Element Titles).

Sequence-style sections such as `Instructions` or `Constraints` may also be deserialized as native arrays when the target schema expects ordered items.
That mapping is a deserializer convention above the MOL syntax layer.




## Comments and Whitespace

Blank lines may be used freely to improve readability.

The following comment forms are extensions to markdown and are ignored by MOL parsers:

- Line comments: `// comment`
- Block comments: `/* comment */`

Comments may appear anywhere a blank line could appear.

Thematic breaks (---) may be used anywhere where a blank line could appear.





## Markdown Compatibility

### Markdown Backwards Compatibility

MOL intentionally reuses common markdown constructs:

- Headings: `# Heading`
- Unordered lists: `- Item`, `* Item`, `+ Item`
- Ordered lists: `1. Item`

### MOL Extensions

MOL extends markdown with:

- Object semantics for headings, list items, and `Key: Value` lines
- `//` line comments
- `/* ... */` block comments

## Minimal Parsing Guidance

A conforming parser should:

- Ignore comments and blank lines
- Recognize the document's root heading level
- Recognize heading scopes
- Recognize plain and list-based key/value entries
- Recognize key-only entries
- Recognize full-value single-quoted and double-quoted inline string literals
- Decode the basic quoted inline escapes `\\`, `\"`, `\'`, `\n`, `\r`, and `\t`
- Recognize text-body scalar values, including multiline text
- Preserve scalar values as strings at the syntax layer, including ISO 8601 date and datetime forms
- Preserve entry order
- Allow duplicate sibling keys
- Support indentation-based nesting for non-heading entries




## Minimal Serialization Guidance

Every structural form in this specification is valid output, but MOL is written to be read.
Serializers should therefore emit the most readable equivalent form rather than the most compact one.

A conforming serializer should:

- Emit nested entries as headings up to the default heading depth, then fall back to indentation
- Apply the recommended key-name normalization (see Key-Name Normalization)
- Prefer tab characters for emitted indentation
- Preserve entry order, except where heading emission requires otherwise (see Heading Emission Rules)
- Quote inline scalar values that would otherwise be coerced to another type by a reader

### Default Heading Depth

Serializers should emit nested object and array entries as headings for the first **four** levels of
nesting, and use indentation-based nesting below that depth.

Headings are the most markdown-native way to express structure, and MOL is not intended for deeply
nested data, so four levels covers the documents MOL is designed for while keeping deeper
structures from producing unreadable heading chains.

The heading depth must never exceed 6, because markdown defines only `#` through `######`.
A serializer configured with a greater depth must clamp it to 6.

Implementations should expose this depth as a configurable option, where a depth of `0` disables
headings entirely and emits fully indented output.

Example, at the default depth:

```md
Id: 10
Full Name: Jane Doe

# Password

Hash: abc
Version: 19

# Addresses

## Home

City: Zurich
```

The same object, with heading depth `0`:

```md
Id: 10
Full Name: Jane Doe
Password:
	Hash: abc
	Version: 19
Addresses:
	Home:
		City: Zurich
```

Both forms are structurally equivalent, as described in Structural Forms.

### Heading Emission Rules

All content that follows a heading belongs to that heading's scope until a heading of the same or
shallower normalized level. Serializers that emit headings must therefore observe the following
rules, otherwise the document they produce will not read back as the object they were given.

- **Inline entries precede sibling heading entries.**
  Within an object, entries emitted inline must be written before any sibling entries emitted as
  headings. An inline entry written after a sibling heading would be read back as a child of that
  heading. This means object entry order may change when headings are used.

- **Array element order is significant.**
  Repeated entries representing an array must not be reordered. A serializer should only use
  headings for an array when every element can be emitted as a heading; otherwise every element of
  that array should use indentation.

- **Indented scopes cannot contain headings.**
  Once a serializer falls back to indentation, all deeper levels must remain indented. A heading
  closes any open indentation-based scope, so a heading emitted inside an indented entry would
  escape that entry rather than nest inside it.

- **No blank line between a text body and a following heading.**
  Blank lines inside a text body are preserved as part of the value (see Text-Body Values), so a
  trailing blank separator would be absorbed into the preceding scalar.

- **Root-level headings are structural.**
  Multiple headings at the document's normalized root level define the root object as an array (see
  Root Heading Level), and a single root heading is conventionally a document title. A serializer
  that emits root-level entries as headings should document this, and readers should offer an
  option to preserve root headings as keys rather than unwrapping them.

### Array Element Titles

An array is written as repeated sibling entries, so every element carries the same key. For arrays
of records this produces a run of identical generic keys that tells a reader nothing about the
elements:

```md
## Addresses

### Item

Label: Rechnungsadresse
City: Zürich

### Item

Label: Firmenadresse
City: Bern
```

Serializers may offer to name each element after a value taken from that element instead:

```md
## Addresses

### Rechnungsadresse

Label: Rechnungsadresse
City: Zürich

### Firmenadresse

Label: Firmenadresse
City: Bern
```

Both documents are ordinary MOL. The second uses distinct sibling keys where the first uses repeated
ones.

**This changes the data model.** Distinct sibling keys describe a keyed object, while repeated
sibling keys describe an array (see Arrays and Duplicate Keys). Titling an array therefore converts
it to an object keyed by title. Implementations that offer this must document that consequence, and
should leave it disabled by default, so that a value serialized with default settings reads back as
the same shape it was given.

Where an implementation offers this, it should take an ordered list of candidate property names
(suggested option name: `arrayTitleKeys`) and apply the following rules:

- For each element, the first candidate present on that element is used.
- Candidate names should be matched case-insensitively against the element's keys.
- A candidate should be used only when its value is a single scalar that is non-empty once trimmed.
  Anything else falls through to the next candidate.
- Titles come from values, not from key names, and must be emitted verbatim.
  Key-name normalization must not be applied to them.
- Whitespace within a title collapses, because a key or heading occupies a single line.
  The element's own value is unaffected.
- Titling is all-or-nothing per array. If any element yields no title, or if two titles are equal,
  every element should fall back to the generic repeated key. A partly titled array would mix
  object-like and array-like entries in one scope, and equal titles are repeated keys, so only
  those elements would read back as an array.
- Outside heading form a title containing `:` must not be used, because a reader splits a plain
  entry at its first colon.

A root-level array is the one case where titling does not change the shape: headings at the
document's normalized root level are structural whatever they are named (see Root Heading Level),
so a titled root-level array still describes an array.




## Conventions

### Root Heading

The root heading does not need to start at `#`. A document may begin structurally at `#`, `##`, or any deeper heading level.

The first heading depth used for structure becomes normalized level 1 for that document.

Multiple root headings at that normalized level are allowed.

### Preferred Shorthand

Use repeated keys for array-like data and headings for major sections.

Tabs are the preferred indentation style for emitted files, though parsers should be liberal in what they accept.

### File Endings

Official file extension for MOL files: `.mol`

#### Alternate Naming (TBD):

Official file extension for objects: `.mdo` or `.molo`
Official file extension for configurations: `.mdc` or `.molc` (could be useful to easily spot config files, avoids things like tsconfig.json - would be typescript.molc)




## Implementations

- Language specific implementations of MOL should fully comply with the official specifications in all matters.
- Every implementation should be efficient in memory and processing speed, as well as code complexity.
- The codebase should be lean and clean, and easy to understand, maintain and verify.
- Implementation distributables should be dependency free (so long it makes sense).

### Key-Name Normalization

MOL does not define key-name normalization as part of the core format.
Transformations such as camelCase, PascalCase, snake_case, or kebab-case are implementation-specific.

Splitting a key into words should recognize both separator characters (space, underscore, hyphen,
period) and letter-case boundaries, so that keys written as natural words and keys written as
native member names both split correctly.
Example: `Full name`, `full_name`, and `fullName` all split into the words `full` and `name`.

If an implementation exposes named normalization modes, the following terms should be used with these meanings:

- `identity`
  Preserve the key as written, without changing separators or letter casing.
  Example: `Full name` -> `Full name`

- `natural`
  Split the key into words, capitalize each word, and join them with single spaces.
  All-caps initialisms are preserved rather than recapitalized.
  Example: `entityType` -> `Entity Type`, `HTTPServer` -> `HTTP Server`
  This mode should be idempotent: applying it to its own output must not change the result.

- `camelCase`
  Split the key into words, remove separators, lowercase the first word, and capitalize subsequent words.
  Example: `Full name` -> `fullName`

- `PascalCase`
  Split the key into words, remove separators, and capitalize each word.
  Example: `Full name` -> `FullName`

- `snake_case`
  Split the key into words, lowercase them, and join them with underscore characters.
  Example: `Full name` -> `full_name`

- `kebab-case`
  Split the key into words, lowercase them, and join them with hyphen characters.
  Example: `Full name` -> `full-name`

Implementations should document their exact handling of edge cases such as:

- Acronyms and initialisms
- Repeated separators
- Leading digits
- Non-ASCII letters
- Punctuation other than space, underscore, or hyphen

### Recommended Default Normalization

A MOL document is written to be read by humans, so its keys should read as natural words.
A native object is written to be used in a programming language, so its member names follow that
language's naming convention.
These are different audiences, and implementations should bridge them by default rather than
carrying one convention into the other.

The recommended defaults are therefore directional:

- **Deserializing (MOL to native):** normalize natural keys to the naming convention idiomatic for
  the host language or target type.
- **Serializing (native to MOL):** normalize native member names back to `natural`.

Only the direction is specified here. The convention used on the native side is language-dependent,
and each implementation should choose the one its users expect — for example `camelCase` for
JavaScript, TypeScript, and JSON documents, `PascalCase` for .NET, or `snake_case` for Rust and
Python.

The two defaults should be inverses of one another, so that a native object round-trips through MOL
with its member names intact.

Example, using JSON as the native side:

```json
{
  "entityType": "user",
  "postalCode": "8045",
  "sha256Hash": "9b87da04349185080af34e04895d4d66"
}
```

```md
Entity Type: user
Postal Code: "8045"
Sha256 Hash: 9b87da04349185080af34e04895d4d66
```

Reading that MOL document back with the recommended defaults reproduces the original member names.

Implementations must allow both defaults to be overridden, including with `identity` when keys are
to be carried through exactly as written.

## Tests

Each implementation must be able to pass all the tests provided by the mol-specs tests (in ./test-files).
See ./test-files/README.md for more information on tests.
