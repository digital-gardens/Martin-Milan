# demo1.cardOrderManual.tsv Notes

This Case File is part of ANA WorkBench.

## Case Notes

Not provided.

## AI Notes

No AI notes were entered.

## Included Files

1. demo1.metaschema.stt.backup.tsv
   - Original file: demo1.metaschema.stt.backup.tsv
   - Purpose: Not provided.
   - Detected format: tsv
   - Source Notes: No Source Notes were entered.
   - Content path: sources/001-demo1.metaschema.stt.backup.tsv
   - SHA-256: a24efc69d3141be7add2c607a9f257c3b5dce22e58f592ed3843db26666f8cfa

2. demo1.cardOrderManual.tsv
   - Original file: demo1.cardOrderManual.tsv
   - Purpose: Not provided.
   - Detected format: tsv
   - Source Notes: No Source Notes were entered.
   - Content path: sources/002-demo1.cardOrderManual.tsv
   - SHA-256: 636b158d462ce9f8ee1b1a498099f4860257ccdf7c1829ec53d2d78409b83465
