# ANA WorkBench Case File

This Case File is part of ANA WorkBench.

A Case File is a browser-local package containing all files loaded into a WorkBench working group, plus source aliases, source notes, case notes, receipts, and diagnostics.

Read `CASEFILENOTE.md` before interpreting the source files. The notes are human context for the data story; re-run parsing and validation before treating saved diagnostics or receipts as current truth.