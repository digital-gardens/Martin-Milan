# Markdown Hard Break

Add and manage Markdown hard breaks (2 trailing spaces) with ease. This extension helps you properly format Markdown files for correct line break rendering in GitHub, GitLab, and other Markdown processors.

## Features

### Add Hard Break
- **Keyboard Shortcut**: `Ctrl+Shift+Enter` (Mac: `Cmd+Shift+Enter`)
- **Command Palette**: `Markdown: Add Hard Break`

Adds exactly 2 trailing spaces to the current line or selected lines. Smart enough to:
- Never add more than 2 spaces
- Add only what's missing if line already has trailing spaces
- Skip empty lines

### Normalize Hard Breaks
- **Command Palette**: `Markdown: Normalize Hard Breaks`

Ensures every line in your document has exactly 2 trailing spaces. Removes extra spaces if more than 2 exist.

## Usage

### Single Line
Place cursor on a line and press `Ctrl+Shift+Enter` to add a hard break.

### Multiple Lines
Select multiple lines and use the command to add hard breaks to all selected lines.

### Normalize Document
Run `Markdown: Normalize Hard Breaks` to ensure the entire document has consistent hard breaks.

## Behavior

| Original Line | After Add Hard Break | After Normalize |
|---------------|----------------------|-----------------|
| `Hello` | `Hello␠␠` | `Hello␠␠` |
| `Hello␠` | `Hello␠␠` | `Hello␠␠` |
| `Hello␠␠` | `Hello␠␠` | `Hello␠␠` |
| `Hello␠␠␠` | `Hello␠␠␠` | `Hello␠␠` |
| (empty line) | (unchanged) | (unchanged) |

␠ = space character

## Why Hard Breaks?

In Markdown, a single newline is often treated as a space. To create a true line break, you need either:
- Two or more spaces at the end of a line (hard break)
- A backslash (`\`) at the end of a line

This extension handles the trailing spaces approach, which is the most widely supported method.

## Requirements

- VS Code 1.109.0 or later

## Extension Settings

No configuration needed. The extension works out of the box.

## Release Notes

### 1.0.0
- Initial release
- Add Hard Break command with keyboard shortcut
- Normalize Hard Breaks command for document-wide formatting
- Smart trailing space handling (never adds more than 2 spaces)
- Skips empty lines automatically

---

**Enjoy!**
