# Change Log

All notable changes to the "markdown-hard-break" extension will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/).

## [1.0.0] - 2026-03-08

### Added
- `Markdown: Add Hard Break` command with `Ctrl+Shift+Enter` keyboard shortcut
- `Markdown: Normalize Hard Breaks` command for document-wide normalization
- Smart trailing space handling:
  - Never adds more than 2 spaces
  - Adds only missing spaces if line already has trailing spaces
  - Skips empty lines automatically
- Support for multiple line selection

### Features
- Works with current line when no selection
- Works with multiple selected lines
- Consistent behavior across all Markdown files

## [Unreleased]

- Initial development version
