// The module 'vscode' contains the VS Code extensibility API
// Import the module and reference it with the alias vscode in your code below
import * as vscode from 'vscode';

// Constants
const TARGET_SPACES = 2;

/**
 * Calculate how many trailing spaces exist at the end of a line
 * @param lineText - The text of the line
 * @returns Number of trailing spaces
 */
function getTrailingSpaces(lineText: string): number {
    const match = lineText.match(/ *$/);
    return match?.[0].length ?? 0;
}

/**
 * Add hard break (2 trailing spaces) to a single line
 * Only adds spaces if needed - never adds beyond 2 spaces
 * @param line - The vscode.TextLine to modify
 * @param editBuilder - The workspace edit builder
 */
function addHardBreakToLine(line: vscode.TextLine, editBuilder: vscode.TextEditorEdit): void {
    const lineText = line.text;
    
    // Skip empty lines (lines with only whitespace)
    if (lineText.trim().length === 0) {
        return;
    }
    
    // Calculate how many spaces are already at the end
    const trailingSpaces = getTrailingSpaces(lineText);
    
    // Calculate how many more spaces we need to reach 2
    const spacesToAdd = Math.max(0, TARGET_SPACES - trailingSpaces);
    
    // Only insert if we need to add spaces
    if (spacesToAdd > 0) {
        editBuilder.insert(line.range.end, ' '.repeat(spacesToAdd));
    }
}

/**
 * Normalize hard breaks - ensures every line has exactly 2 trailing spaces
 * Removes extra spaces if there are more than 2
 * @param line - The vscode.TextLine to normalize
 * @param editBuilder - The workspace edit builder
 */
function normalizeLineHardBreak(line: vscode.TextLine, editBuilder: vscode.TextEditorEdit): void {
    const lineText = line.text;
    
    // Skip empty lines
    if (lineText.trim().length === 0) {
        return;
    }
    
    // Replace all trailing spaces with exactly 2 spaces
    const normalizedLine = lineText.replace(/ *$/, ' '.repeat(TARGET_SPACES));
    
    // Only replace if the line is different
    if (normalizedLine !== lineText) {
        editBuilder.replace(line.range, normalizedLine);
    }
}

/**
 * Handler for "Add Hard Break" command
 * Adds 2 trailing spaces to selected lines (or current line)
 * Only adds spaces if needed - never exceeds 2 spaces
 */
function handleAddHardBreak(): void {
    const editor = vscode.window.activeTextEditor;
    if (!editor) {
        return;
    }
    
    const document = editor.document;
    const selection = editor.selection;
    
    // Determine which lines to process
    let startLine: number;
    let endLine: number;
    
    if (selection.isEmpty) {
        // No selection - use current line
        startLine = selection.active.line;
        endLine = selection.active.line;
    } else {
        // Selection exists - process all lines in selection
        startLine = Math.min(selection.start.line, selection.end.line);
        endLine = Math.max(selection.start.line, selection.end.line);
    }
    
    // Apply to each line in range
    editor.edit((editBuilder) => {
        for (let i = startLine; i <= endLine; i++) {
            const line = document.lineAt(i);
            addHardBreakToLine(line, editBuilder);
        }
    });
}

/**
 * Handler for "Normalize Hard Breaks" command
 * Ensures every line has exactly 2 trailing spaces
 * Removes extra spaces if there are more than 2
 */
function handleNormalizeHardBreaks(): void {
    const editor = vscode.window.activeTextEditor;
    if (!editor) {
        return;
    }
    
    const document = editor.document;
    const lineCount = document.lineCount;
    
    // Apply to all lines in the document
    editor.edit((editBuilder) => {
        for (let i = 0; i < lineCount; i++) {
            const line = document.lineAt(i);
            normalizeLineHardBreak(line, editBuilder);
        }
    });
}

// This method is called when your extension is activated
export function activate(context: vscode.ExtensionContext): void {
    console.log('Congratulations, your extension "markdown-hard-break" is now active!');

    // Register "Add Hard Break" command
    const addHardBreakCmd = vscode.commands.registerCommand(
        'markdown-hard-break.addHardBreak',
        handleAddHardBreak
    );
    context.subscriptions.push(addHardBreakCmd);

    // Register "Normalize Hard Breaks" command
    const normalizeHardBreaksCmd = vscode.commands.registerCommand(
        'markdown-hard-break.normalizeHardBreaks',
        handleNormalizeHardBreaks
    );
    context.subscriptions.push(normalizeHardBreaksCmd);
}

// This method is called when your extension is deactivated
export function deactivate(): void {}
